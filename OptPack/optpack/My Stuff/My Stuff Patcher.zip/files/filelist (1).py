import os

def filepaths():
    current_directory = os.getcwd()
    with open('download_list.txt', 'a') as file:
        for root, _, files in os.walk(current_directory):
            if root != current_directory:  # Skip files directly in the root directory
                for name in files:
                    relative_path = os.path.relpath(os.path.join(root, name), current_directory)
                    filepath = relative_path.replace("\\", "/")
                    file.write(f"{filepath.rstrip()}\n")  # Remove trailing whitespace

filepaths()